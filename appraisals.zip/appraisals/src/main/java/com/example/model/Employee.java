package com.example.model;

import java.sql.Date;
import java.time.LocalDate;

public class Employee {
	private String empId;
	private String empName;
	private LocalDate empDOJ;
	private int empRating;
	private long empSalary;
	private long empRevisedSalary;
	private String managerComment;
	private int hikePercentage;
	private String appraisalComment;
	private LocalDate resignDate;
	private boolean PIPInitiated;
	private double bonus;
	private LocalDate revisedSalaryApplicationDate;
	
	public Employee(String empId, String empName, LocalDate empDOJ, int empRating, long empSalary,
			long empRevisedSalary, String managerComment, int hikePercentage, String appraisalComment,
			LocalDate resignDate, boolean pIPInitiated, double bonus, LocalDate revisedSalaryApplicationDate) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empDOJ = empDOJ;
		this.empRating = empRating;
		this.empSalary = empSalary;
		this.empRevisedSalary = empRevisedSalary;
		this.managerComment = managerComment;
		this.hikePercentage = hikePercentage;
		this.appraisalComment = appraisalComment;
		this.resignDate = resignDate;
		PIPInitiated = pIPInitiated;
		this.bonus = bonus;
		this.revisedSalaryApplicationDate = revisedSalaryApplicationDate;
	}
	public LocalDate getRevisedSalaryApplicationDate() {
		return revisedSalaryApplicationDate;
	}
	public void setRevisedSalaryApplicationDate(LocalDate revisedSalaryApplicationDate) {
		this.revisedSalaryApplicationDate = revisedSalaryApplicationDate;
	}
	public Employee() {
		
	}

	public double getBonus() {
		return bonus;
	}

	public void setBonus(double bonus) {
		this.bonus = bonus;
	}

	public String getAppraisalComment() {
		return appraisalComment;
	}
	public void setAppraisalComment(String appraisalComment) {
		this.appraisalComment = appraisalComment;
	}
	public LocalDate getResignDate() {
		return resignDate;
	}
	public void setResignDate(LocalDate resignDate) {
		this.resignDate = resignDate;
	}
	public boolean isPIPInitiated() {
		return PIPInitiated;
	}
	public void setPIPInitiated(boolean pIPInitiated) {
		PIPInitiated = pIPInitiated;
	}
	public String getEmpId() {
		return empId;
	}
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	public String getEmpName() {
		return empName;
	}
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	public LocalDate getEmpDOJ() {
		return empDOJ;
	}
	public void setEmpDOJ(LocalDate empDOJ) {
		this.empDOJ = empDOJ;
	}
	public int getEmpRating() {
		return empRating;
	}
	public void setEmpRating(int empRating) {
		this.empRating = empRating;
	}
	public long getEmpSalary() {
		return empSalary;
	}
	public void setEmpSalary(long empSalary) {
		this.empSalary = empSalary;
	}
	public long getEmpRevisedSalary() {
		return empRevisedSalary;
	}
	public void setEmpRevisedSalary(long empRevisedSalary) {
		this.empRevisedSalary = empRevisedSalary;
	}
	public String getManagerComment() {
		return managerComment;
	}
	public void setManagerComment(String managerComment) {
		this.managerComment = managerComment;
	}
	public int getHikePercentage() {
		return hikePercentage;
	}
	public void setHikePercentage(int hikePercentage) {
		this.hikePercentage = hikePercentage;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empDOJ=" + empDOJ + ", empRating=" + empRating
				+ ", empSalary=" + empSalary + ", empRevisedSalary=" + empRevisedSalary + ", managerComment="
				+ managerComment + ", hikePercentage=" + hikePercentage + ", appraisalComment=" + appraisalComment
				+ ", resignDate=" + resignDate + ", PIPInitiated=" + PIPInitiated + ", bonus=" + bonus
				+ ", revisedSalaryApplicationDate=" + revisedSalaryApplicationDate + "]";
	}
	

}
