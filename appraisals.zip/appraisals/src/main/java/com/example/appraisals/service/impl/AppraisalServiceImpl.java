package com.example.appraisals.service.impl;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.appraisals.dao.AppraisalsDao;
import com.example.appraisals.service.AppraisalService;
import com.example.model.Employee;

@Service
public class AppraisalServiceImpl implements AppraisalService {

	@Autowired
	AppraisalsDao appraisalsDao;
	
	public ArrayList<Employee> getemployeeList() {
		return this.appraisalsDao.getemployeeList();
	}

	@Override
	public String updateData(ArrayList<Employee> empList) {
		return this.appraisalsDao.updateData(empList);
	}
	
	@Override
	public ArrayList<Employee> getEmployeesTobeTrained(ArrayList<Employee> empList) {
		return this.appraisalsDao.getEmployeesTobeTrained(empList);
	}
		
}
