package com.example.appraisals;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class AppraisalsApplication {

	public static void main(String[] args) {
		SpringApplication.run(AppraisalsApplication.class, args);
	}

}
