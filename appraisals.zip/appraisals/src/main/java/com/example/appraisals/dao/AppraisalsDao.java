package com.example.appraisals.dao;

import java.util.ArrayList;

import com.example.model.Employee;

public interface AppraisalsDao {
	public ArrayList<Employee> getemployeeList();
	public String updateData(ArrayList<Employee> empList);
	public ArrayList<Employee> getEmployeesTobeTrained(ArrayList<Employee> empList);
}
