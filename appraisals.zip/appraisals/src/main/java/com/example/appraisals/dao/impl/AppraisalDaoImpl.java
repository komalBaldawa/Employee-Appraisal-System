package com.example.appraisals.dao.impl;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.sql.Date;
import java.time.LocalDate;
import java.util.HashMap;
import java.util.Map;
import java.util.function.Function;
import java.util.stream.Collector;
import java.util.stream.Collectors;

import org.springframework.stereotype.Repository;

import com.example.appraisals.dao.AppraisalsDao;
import com.example.model.Employee;
import com.fasterxml.jackson.databind.ObjectMapper;

import ch.qos.logback.core.pattern.parser.Parser;
import net.minidev.json.JSONArray;

import org.apache.tomcat.util.json.JSONParser;
import org.apache.tomcat.util.json.ParseException;
import org.json.JSONObject;

@Repository
public class AppraisalDaoImpl implements AppraisalsDao {

	public ArrayList<Employee> getemployeeList() {

		ArrayList<Employee> empList = new ArrayList<Employee>();
		Employee emp = new Employee("1234", "Romin Irani", LocalDate.of(1993, 04, 21), 5, 10000, 0, "test", 0, null, null, false,0, null);
		empList.add(emp);
		emp = new Employee("1222", "Komal Irani", LocalDate.of(2015, 10, 21), 4, 120000, 0, "test", 0, null, null, false,0, null);
		empList.add(emp);
		emp = new Employee("122", "Sayali Irani", LocalDate.of(2005, 10, 21), 3, 1202200, 0, "test", 0, null, null, false,0, null);
		empList.add(emp);
		emp = new Employee("1222", "Preetam Irani", LocalDate.of(2015, 10, 21), 2, 129000, 0, "test", 0, null, null, false,0,null);
		empList.add(emp);
		emp = new Employee("1222", "Kapil Irani", LocalDate.of(2015, 10, 21), 1, 122000, 0, "test", 0, null, null, false,0,null);
		empList.add(emp);
		emp = new Employee("1222", "Kapil Irani", LocalDate.of(2022, 5, 21), 1, 122000, 0, "test", 0, null, null, false,0,null);
		empList.add(emp);
		empList = processEmplist(empList);
		return empList;
	}

	public ArrayList<Employee> processEmplist(ArrayList<Employee> empList) {
		// empList = empList.stream().map((emp) -> emp.getEmpRating() == 5 ?
		// emp.setHikePercentage(10)).collect(Collectors.toList());
		LocalDate beforeayear = LocalDate.now().minusYears(1);

		// Date beforeYear = new Date(new Date().getDate(), new
		// Date().getMonth(), new Date().getYear()-1);
		empList.forEach(emp -> {
			if (emp.getEmpDOJ().isBefore(beforeayear) && emp.getResignDate() == null) {
				switch (emp.getEmpRating()) {
				case 5:
					emp.setHikePercentage(10);
					emp.setEmpRevisedSalary((long) (emp.getEmpSalary() * 1.10));
					break;
				case 4:
					emp.setHikePercentage(7);
					emp.setEmpRevisedSalary((long) (emp.getEmpSalary() * 1.07));
					break;
				case 3:
					emp.setHikePercentage(5);
					emp.setEmpRevisedSalary((long) (emp.getEmpSalary() * 1.05));
					break;
				case 2:
				case 1:
					emp.setManagerComment("Trainings to be taken");
					emp.setEmpRevisedSalary(emp.getEmpSalary());
					break;
				}
			} else {
				emp.setEmpRevisedSalary(emp.getEmpSalary());
			}
			emp.setRevisedSalaryApplicationDate(LocalDate.of(LocalDate.now().getYear(), LocalDate.now().plusMonths(1).getMonth(), 01));

		});
		return empList;
	}

	@Override
	public String updateData(ArrayList<Employee> empList) {
		
		return "Data Saved SUccessfully";
	}

	@Override
	public ArrayList<Employee> getEmployeesTobeTrained(ArrayList<Employee> empList) {
		empList = (ArrayList<Employee>) empList.stream().filter(emp -> emp.getEmpRating() < 3).collect(Collectors.toList());
		return empList;
	}
	
}
