package com.example.appraisals.service;

import java.util.ArrayList;

import com.example.model.Employee;

public interface AppraisalService {
	public ArrayList<Employee> getemployeeList();
	public String updateData(ArrayList<Employee> empList);
	public ArrayList<Employee> getEmployeesTobeTrained(ArrayList<Employee> empList);
}
