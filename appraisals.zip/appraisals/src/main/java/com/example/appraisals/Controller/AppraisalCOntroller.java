package com.example.appraisals.Controller;

import java.util.ArrayList;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.client.RestClientTest;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RestController;

import com.example.appraisals.service.AppraisalService;
import com.example.model.Employee;


@RestController
public class AppraisalCOntroller {
	
	@Autowired
	AppraisalService appraisalsService;

	@RequestMapping("/hello")
	public String helloWorld() {
		return "Hello World";
	}
	
	@CrossOrigin
	@RequestMapping("/getEmployeeData") 
	public ArrayList<Employee> getEmployeeData() {
		return this.appraisalsService.getemployeeList();
	}
	
	@CrossOrigin
	@PostMapping("/getEmployeeTobeTRained") 
	public ArrayList<Employee> getEmployeeTobeTRained(@RequestBody ArrayList<Employee> empList) {
		return this.appraisalsService.getEmployeesTobeTrained(empList);
	}
	
	@CrossOrigin
	@PostMapping("/updateData") 
	public String updateData(@RequestBody ArrayList<Employee> empList) {
		return this.appraisalsService.updateData(empList);
	}
}
