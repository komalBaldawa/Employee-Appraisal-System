import { Injectable } from "@angular/core";
import { HttpClient,HttpParams ,HttpHeaders} from '@angular/common/http';

@Injectable({
    providedIn: 'root'
})
export class EmployeeListService {
    private GET_EMPLOYEELIST = 'http://localhost:8080/getEmployeeData';
    private GET_EMPLOYEELISTTOBETRAINED = 'http://localhost:8080/getEmployeeTobeTRained';
    private UPDATE_EMPLOYEE_DATA = 'http://localhost:8080/updateData';

    constructor(private httpClient: HttpClient) { }

    public getEmployeeDate() {
        return this.httpClient.get(this.GET_EMPLOYEELIST);
    }

    public getEMployeeLIstTobeTRained(employeeListt) {
        return this.httpClient.post(this.GET_EMPLOYEELISTTOBETRAINED, employeeListt);

    }

    public updateEmployee(employeeListt) {
        return this.httpClient.post(this.UPDATE_EMPLOYEE_DATA, employeeListt);

    }
}