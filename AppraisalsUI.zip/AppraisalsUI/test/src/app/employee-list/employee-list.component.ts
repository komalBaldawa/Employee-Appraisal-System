import { Component, OnInit } from '@angular/core';
import { EmployeeListService } from './employee-list.service';

@Component({
  selector: 'app-employee-list',
  templateUrl: './employee-list.component.html',
  styleUrls: ['./employee-list.component.css']
})
export class EmployeeListComponent implements OnInit {

  employeeList: any = [];
  employeeListTobeTRained: any = [];
  constructor(private employeeService: EmployeeListService) { }

  ngOnInit(): void {
    this.employeeService.getEmployeeDate().subscribe(Response => {
      this.employeeList = Response;
      this.employeeService.getEMployeeLIstTobeTRained(this.employeeList).subscribe(response => {
        this.employeeListTobeTRained = response;
      })
    })
  }

  ratingChanged(emp, event) {
    let lastyear = new Date();
    //emp.empRating = Number(event.target.value);
    lastyear.setFullYear(lastyear.getFullYear() - 1);
    console.log(new Date(emp.empDOJ) < lastyear);
    if (new Date(emp.empDOJ) < lastyear && emp.resignDate == null) {
      switch (emp.empRating) {
        case 5:
          emp.hikePercentage = 10;
          break;
        case 4:
          emp.hikePercentage = 7;
          break;
        case 3:
          emp.hikePercentage = 5;
          break;
        case 2:
        case 1:
          emp.hikePercentage = 0;
          break;
      }
      emp.empRevisedSalary = emp.empSalary * emp.hikePercentage / 100 +  emp.empSalary;
    }
  }

  SubmitData() {
    this.employeeService.updateEmployee(this.employeeList).subscribe(response => {
      alert("data Saved SUcessfully");
    })
  }

}
